"""Configuration for the zedpy agent — enterprise-grade settings.

Defaults are here (opencode zen endpoint + mimo-v2.5-free). Override via env:

    ZEDPY_API_KEY     -> API key
    ZEDPY_BASE_URL    -> chat completions endpoint (full URL)
    ZEDPY_MODEL       -> model id
    ZEDPY_MAX_STEPS   -> ReAct loop max steps (default 80)
    ZEDPY_MAX_TOKENS  -> max output tokens (default 1M)
    ZEDPY_EFFORT      -> effort level (normal|max|ultra|ultracombomax|goal|dream)
    ZEDPY_WORKDIR     -> working directory override
    ZEDPY_AUTO_APPROVE -> auto-approve all actions (true/false)

SECURITY NOTE: The default key below is in plaintext for convenience.
In production, use ZEDPY_API_KEY env var and rotate regularly.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field


# --- Built-in defaults ---
# API key: prefer environment variable; fallback is a placeholder (not a real key).
DEFAULT_API_KEY = os.environ.get("ZEDPY_API_KEY", "")
DEFAULT_BASE_URL = os.environ.get(
    "ZEDPY_BASE_URL",
    "https://opencode.ai/zen/v1/chat/completions",
)
DEFAULT_MODEL = "mimo-v2.5-free"
DEFAULT_MAX_STEPS = 80
DEFAULT_MAX_TOKENS = 1000000
DEFAULT_TIMEOUT = 4000

# Cloudflare Workers AI defaults
CF_ACCOUNT_ID = os.environ.get("CF_ACCOUNT_ID", "3e7e3455b42e2ab337710bd91f381ef0")
CF_API_KEY = os.environ.get("CF_API_KEY", "cfut_OlYbjP2qM6iHjpCbMqDFKSk5xkkXlAM07J9smAUl3f9dd933")
CF_BASE_URL = f"https://api.cloudflare.com/client/v4/accounts/{CF_ACCOUNT_ID}/ai/v1/chat/completions"


@dataclass
class ModelProfile:
    """Pre-configured model profiles for common use-cases."""
    name: str
    model: str
    base_url: str
    max_tokens: int = 1_000_000
    temperature: float = 0.2
    supports_streaming: bool = True
    supports_tools: bool = True


# Built-in model profiles — user /model can select these.
MODEL_PROFILES: dict[str, ModelProfile] = {
    "mimo": ModelProfile(
        name="mimo", model="mimo-v2.5-free",
        base_url="https://opencode.ai/zen/v1/chat/completions",
    ),
    "fast": ModelProfile(
        name="fast", model="mimo-v2.5-free",
        base_url="https://opencode.ai/zen/v1/chat/completions",
        max_tokens=500_000,
    ),
    # Cloudflare Workers AI models
    # NOTE: CF models have shared context windows (input+output combined).
    # max_tokens = total - headroom for input tokens.
    "glm": ModelProfile(
        name="glm", model="@cf/zai-org/glm-5.2",
        base_url=CF_BASE_URL,
        max_tokens=250_000,   # 256K total - 6K input headroom
        supports_tools=False,  # Cloudflare AI doesn't support tool calling yet
    ),
    "kimi": ModelProfile(
        name="kimi", model="@cf/moonshotai/kimi-k2.7-code",
        base_url=CF_BASE_URL,
        max_tokens=200_000,   # 262K total - 62K input headroom
        supports_tools=False,
    ),
}


@dataclass
class Config:
    api_key: str = DEFAULT_API_KEY
    base_url: str = DEFAULT_BASE_URL
    model: str = DEFAULT_MODEL
    max_steps: int = DEFAULT_MAX_STEPS
    max_tokens: int = DEFAULT_MAX_TOKENS
    timeout: int = DEFAULT_TIMEOUT
    workdir: str = ""
    auto_approve: bool = False
    plan_mode: bool = False
    auto_test: bool = False
    test_command: str = ""
    effort: str = "normal"
    # Advanced configuration
    context_window_limit: int = 200_000  # Max tokens before compression triggers
    summary_ratio: float = 0.3  # When compressing, keep this fraction of history
    max_concurrent_tools: int = 5  # Parallel tool execution limit
    enable_caching: bool = True  # Cache repeated LLM calls for identical prompts
    debug_mode: bool = False  # Extra logging
    yolo_mode: bool = False  # Alias for auto_approve

    @classmethod
    def load(cls) -> "Config":
        """Env vars overlay defaults."""
        auto_approve = os.getenv("ZEDPY_AUTO_APPROVE", "").lower() in ("true", "1", "yes")
        effort = os.getenv("ZEDPY_EFFORT", "normal")
        workdir = os.getenv("ZEDPY_WORKDIR", "") or os.getcwd()
        return cls(
            api_key=os.getenv("ZEDPY_API_KEY", DEFAULT_API_KEY),
            base_url=os.getenv("ZEDPY_BASE_URL", DEFAULT_BASE_URL),
            model=os.getenv("ZEDPY_MODEL", DEFAULT_MODEL),
            max_steps=int(os.getenv("ZEDPY_MAX_STEPS", str(DEFAULT_MAX_STEPS))),
            max_tokens=int(os.getenv("ZEDPY_MAX_TOKENS", str(DEFAULT_MAX_TOKENS))),
            timeout=int(os.getenv("ZEDPY_TIMEOUT", str(DEFAULT_TIMEOUT))),
            workdir=os.path.abspath(workdir),
            auto_approve=auto_approve,
            effort=effort,
            context_window_limit=int(os.getenv("ZEDPY_CONTEXT_LIMIT", "200000")),
            debug_mode=os.getenv("ZEDPY_DEBUG", "").lower() in ("true", "1"),
        )

    def apply_profile(self, name: str) -> bool:
        """Apply a named model profile. Returns True if found.

        Cloudflare profiles auto-set the CF API key.
        """
        profile = MODEL_PROFILES.get(name.lower())
        if profile is None:
            return False
        self.model = profile.model
        self.base_url = profile.base_url
        self.max_tokens = profile.max_tokens
        # Auto-switch API key for Cloudflare profiles.
        if "cloudflare.com" in profile.base_url:
            self.api_key = CF_API_KEY
        return True
